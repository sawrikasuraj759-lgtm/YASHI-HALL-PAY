YASHI HALLS Android Studio starter project

1. Extract this ZIP.
2. Android Studio > Open > select the YashiHalls folder.
3. Wait for Gradle Sync. If prompted, install Android SDK 35.
4. Connect Android phone with USB debugging enabled, then press Run.

මෙය පළමු UI + permission prototype එකයි. Bot link key එක local phone storage එකේ save වෙනවා. SMS/notification contents server එකකට යවන්නේ නැහැ. Bot server protocol එක නොදන්නා නිසා actual bot connection සහ automatic delivery තවම configure කර නැහැ.

Security:
- SMS access Android permission එකෙන් පමණක්.
- Notification access user විසින් Settings තුළින්ම enable කළ යුතුයි.
- SMS/notification content log/upload කරන්නේ නැහැ.
- OTP, PIN, password කිසිවිටෙක collect කරන්න එපා.
- Production use එකට bank/payment webhook හෝ trusted merchant API එකක් හරහා payment confirm කරන්න.
