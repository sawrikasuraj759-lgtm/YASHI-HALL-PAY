package com.yashi.halls

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Bg = Color(0xFF090713)
private val Panel = Color(0xFF171329)
private val Purple = Color(0xFF9B6CFF)
private val Mint = Color(0xFF62E6C2)

class MainActivity : ComponentActivity() {
    private val smsPermission = registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        Toast.makeText(this, if (granted) "SMS permission enabled" else "SMS permission not granted", Toast.LENGTH_SHORT).show()
    }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences("yashi_halls", MODE_PRIVATE)
        setContent {
            var token by remember { mutableStateOf(prefs.getString("link_key", "") ?: "") }
            var linked by remember { mutableStateOf(prefs.getBoolean("linked", false)) }
            var smsGranted by remember { mutableStateOf(checkSelfPermission(Manifest.permission.RECEIVE_SMS) == PackageManager.PERMISSION_GRANTED) }
            var notificationEnabled by remember { mutableStateOf(isNotificationAccessEnabled()) }
            MaterialTheme(colorScheme = darkColorScheme(primary = Purple, background = Bg, surface = Panel)) {
                Column(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF17102D), Bg, Color(0xFF080B14)))).verticalScroll(rememberScrollState()).padding(20.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
                    Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("YASHI HALLS", color = Color.White, fontSize = 27.sp, fontWeight = FontWeight.Black)
                        Text("PAYMENT CONNECTOR", color = Purple, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 3.sp)
                        Spacer(Modifier.height(8.dp))
                        Text("Secure • Smart • Automatic", color = Color.LightGray, fontSize = 12.sp)
                    }
                    Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(22.dp)) {
                        Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                            Text("BOT CONNECTION", color = Purple, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                            OutlinedTextField(value = token, onValueChange = { token = it }, modifier = Modifier.fillMaxWidth(), label = { Text("Enter Bot Link Key") }, placeholder = { Text("Paste your key here") }, singleLine = true, visualTransformation = PasswordVisualTransformation())
                            Button(onClick = {
                                if (token.isBlank()) Toast.makeText(this@MainActivity, "Enter your link key first", Toast.LENGTH_SHORT).show()
                                else { prefs.edit().putString("link_key", token).putBoolean("linked", false).apply(); linked = false; Toast.makeText(this@MainActivity, "Key saved locally. Server linking is not configured yet.", Toast.LENGTH_LONG).show() }
                            }, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp)) { Text("SAVE LINK KEY") }
                            StatusLine("Bot status", if (linked) "CONNECTED" else "NOT LINKED", linked)
                        }
                    }
                    Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(22.dp)) {
                        Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                            Text("PHONE PERMISSIONS", color = Purple, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                            StatusLine("SMS access", if (smsGranted) "GRANTED" else "NOT GRANTED", smsGranted)
                            Button(onClick = { smsPermission.launch(Manifest.permission.RECEIVE_SMS) }, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp)) { Text("ALLOW SMS ACCESS") }
                            Divider(color = Color(0xFF39314F))
                            StatusLine("Notification access", if (notificationEnabled) "GRANTED" else "NOT GRANTED", notificationEnabled)
                            OutlinedButton(onClick = { startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)) }, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp)) { Text("OPEN NOTIFICATION ACCESS") }
                        }
                    }
                    Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(22.dp)) {
                        Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text("PAYMENT MONITOR", color = Purple, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                            Text("0", color = Mint, fontSize = 34.sp, fontWeight = FontWeight.Black)
                            Text("Verified payments", color = Color.LightGray, fontSize = 12.sp)
                            Text("Waiting for a secure bot connection", color = Color.Gray, fontSize = 11.sp)
                        }
                    }
                    Text("YASHI HALLS • VERSION 1.0", color = Color.Gray, fontSize = 10.sp, modifier = Modifier.align(Alignment.CenterHorizontally))
                }
            }
        }
    }
    override fun onResume() { super.onResume() }
    private fun isNotificationAccessEnabled(): Boolean {
        val enabled = Settings.Secure.getString(contentResolver, "enabled_notification_listeners") ?: return false
        return enabled.contains(packageName)
    }
}

@Composable private fun StatusLine(label: String, value: String, ok: Boolean) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
        Text(label, color = Color.White, fontSize = 13.sp)
        Text(value, color = if (ok) Mint else Color(0xFFFFC46B), fontSize = 10.sp, fontWeight = FontWeight.Bold)
    }
}
