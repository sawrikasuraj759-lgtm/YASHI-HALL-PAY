package com.yashi.halls

import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import android.util.Log

/** Starter listener: observes notifications only after the user explicitly enables access in Android Settings. */
class PaymentNotificationListener : NotificationListenerService() {
    override fun onNotificationPosted(sbn: StatusBarNotification) {
        // TODO: filter only explicitly configured bank/payment apps. Do not capture unrelated notifications.
        Log.i("YASHI_HALLS", "Notification event from package: ${sbn.packageName}; content not uploaded.")
    }
}
