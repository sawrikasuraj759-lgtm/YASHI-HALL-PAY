package com.yashi.halls

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.provider.Telephony
import android.util.Log

/** Starter receiver: intentionally does not forward or store SMS contents yet. */
class PaymentSmsReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Telephony.Sms.Intents.SMS_RECEIVED_ACTION) return
        val messages = Telephony.Sms.Intents.getMessagesFromIntent(intent)
        // TODO: add a strict allow-list for the user's own bank sender IDs and parse only payment alerts.
        // Never upload OTPs, PINs, passwords, or full personal SMS conversations.
        Log.i("YASHI_HALLS", "Received ${messages.size} SMS segment(s); content not logged or uploaded.")
    }
}
